from flask import Flask

app = Flask(__name__)